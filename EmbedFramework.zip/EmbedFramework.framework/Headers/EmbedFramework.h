//
//  EmbedFramework.h
//  EmbedFramework
//
//  Created by Dmitry Smolyakov on 6/8/17.
//  Copyright © 2017 Dmitry Smolyakov. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EmbedFramework.
FOUNDATION_EXPORT double EmbedFrameworkVersionNumber;

//! Project version string for EmbedFramework.
FOUNDATION_EXPORT const unsigned char EmbedFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EmbedFramework/PublicHeader.h>


typedef NS_ENUM(NSInteger, DocumentReaderErrorCode)
{
    RPRM_Error_NoError_ = 0,
    RPRM_Error_LicenseError_ = 1,
    RPRM_Error_NotInitialized_ = 2
};
typedef NS_ENUM(NSInteger, DocumentReaderCommand)
{
    ePC_ProcMgr_SetLicense_ = 12100,                          // initialize ProcMgr
    ePC_ProcMgr_Process_ = 12101,                             // process images and return result
    ePC_ProcMgr_ProcessAsync_ = 12102,                        // start asynchronous processing and return currently available
};

@interface EmbedFramework : NSObject

-(DocumentReaderErrorCode)process:
(DocumentReaderCommand) p_cmd
                       inputImage:(UIImage *)p_inputImage
                        inputJSON:(NSString *)p_inputJSON
                      outputImage:(UIImage **)p_outputImage
                       outputJSON:(NSString **)p_outputJSON;

@end

