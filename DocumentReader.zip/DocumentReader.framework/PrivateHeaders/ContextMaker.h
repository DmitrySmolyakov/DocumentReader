//
//  ContextMaker.h
//  CameraViewController
//
//  Created by Dmitry Smolyakov on 3/28/17.
//  Copyright © 2017 Dmitry Smolyakov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreImage/CoreImage.h>

@interface ContextMaker : NSObject

+ (CIContext*) makeMeAContext;

@end
