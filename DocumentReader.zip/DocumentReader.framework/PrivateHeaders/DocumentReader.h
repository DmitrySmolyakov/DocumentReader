//
//  DocumentReader.h
//  DocumentReader
//
//  Created by Игорь Клещёв on 15.04.17.
//  Copyright © 2017 Regula Forensics. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DocumentReader.
FOUNDATION_EXPORT double DocumentReaderVersionNumber;

//! Project version string for DocumentReader.
FOUNDATION_EXPORT const unsigned char DocumentReaderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DocumentReader/PublicHeader.h>
#import <DocumentReader/ContextMaker.h>

typedef NS_ENUM(NSInteger, DocumentReaderErrorCode)
{
    RPRM_Error_NoError = 0
};
typedef NS_ENUM(NSInteger, DocumentReaderCommand)
{
    RPRM_Command_Process = 0
};

@interface DocumentReader: NSObject

-(DocumentReaderErrorCode)process:
(DocumentReaderCommand) command
inputImage:(UIImage *)p_inputImage
inputJSON:(NSString *)p_inputJSON
outputImage:(UIImage **)p_outputImage
outputJSON:(NSString **)p_outputJSON;

@end
